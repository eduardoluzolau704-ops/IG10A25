import { GraduationCap, Heart, ArrowUp } from 'lucide-react';

const footerLinks = [
  {
    title: 'Navegação',
    links: [
      { label: 'Início', href: '#hero' },
      { label: 'Sobre', href: '#about' },
      { label: 'Horário', href: '#schedule' },
      { label: 'Disciplinas', href: '#subjects' },
      { label: 'Galeria', href: '#gallery' },
      { label: 'Contato', href: '#contact' },
    ],
  },
  {
    title: 'Disciplinas',
    links: [
      { label: 'Programação Web', href: '#subjects' },
      { label: 'Bases de Dados', href: '#subjects' },
      { label: 'POO', href: '#subjects' },
      { label: 'Análise de Sistemas', href: '#subjects' },
    ],
  },
  {
    title: 'Recursos',
    links: [
      { label: 'Material de Estudo', href: '#' },
      { label: 'Projetos', href: '#gallery' },
      { label: 'Calendário', href: '#schedule' },
      { label: 'Documentos', href: '#' },
    ],
  },
];

export function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="relative py-16 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-12 mb-12">
          {/* Brand */}
          <div className="lg:col-span-2">
            <a href="#hero" onClick={(e) => { e.preventDefault(); scrollToSection('#hero'); }} className="flex items-center gap-2 group mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center group-hover:shadow-glow transition-shadow">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <span className="font-bold text-xl text-gradient">IG10A25</span>
            </a>
            <p className="text-muted-foreground mb-6 max-w-sm">
              Turma de Informática de Gestão 2024/2025. 
              Formando profissionais para o futuro da tecnologia.
            </p>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>Feito com</span>
              <Heart className="w-4 h-4 text-red-500 fill-red-500" />
              <span>pela turma IG10A25</span>
            </div>
          </div>

          {/* Links */}
          {footerLinks.map((section) => (
            <div key={section.title}>
              <h4 className="font-semibold mb-4">{section.title}</h4>
              <ul className="space-y-3">
                {section.links.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      onClick={(e) => {
                        if (link.href.startsWith('#')) {
                          e.preventDefault();
                          scrollToSection(link.href);
                        }
                      }}
                      className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground">
            © 2024/2025 IG10A25. Todos os direitos reservados.
          </p>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-2 px-4 py-2 rounded-xl glass hover:bg-white/10 transition-colors text-sm"
          >
            <span>Voltar ao topo</span>
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>
      </div>
    </footer>
  );
}
