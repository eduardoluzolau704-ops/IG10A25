# 🎓 IG10A25 - Site da Turma de Informática de Gestão

Site oficial da turma **IG10A25** de Informática de Gestão.

![Preview](https://img.shields.io/badge/React-18-blue?style=flat-square&logo=react)
![Preview](https://img.shields.io/badge/TypeScript-5.0-blue?style=flat-square&logo=typescript)
![Preview](https://img.shields.io/badge/Tailwind-3.4-cyan?style=flat-square&logo=tailwindcss)
![Preview](https://img.shields.io/badge/Vite-5.0-purple?style=flat-square&logo=vite)

## 🌐 Demo

Acesse o site: [https://ilvgd7rcd6x2u.ok.kimi.link](https://ilvgd7rcd6x2u.ok.kimi.link)

## ✨ Funcionalidades

- 🎯 **Hero Section** - Animação de partículas interativas
- 📊 **Sobre a Turma** - Estatísticas animadas
- 📅 **Horário de Aulas** - Visualização semanal completa
- 📚 **Disciplinas** - Cards interativos com detalhes
- 🖼️ **Galeria** - Momentos especiais da turma
- 📧 **Contato** - Formulário funcional

## 🚀 Tecnologias

- **React 18** - Biblioteca UI
- **TypeScript** - Tipagem estática
- **Tailwind CSS** - Estilização
- **Vite** - Build tool
- **shadcn/ui** - Componentes UI
- **Lucide React** - Ícones

## 📦 Instalação

```bash
# Clone o repositório
git clone https://github.com/seu-usuario/ig10a25-site.git

# Entre na pasta
cd ig10a25-site

# Instale as dependências
npm install

# Inicie o servidor de desenvolvimento
npm run dev
```

## 🛠️ Scripts

| Comando | Descrição |
|---------|-----------|
| `npm run dev` | Inicia servidor de desenvolvimento |
| `npm run build` | Cria build de produção |
| `npm run preview` | Visualiza build de produção |
| `npm run lint` | Executa ESLint |

## 📁 Estrutura do Projeto

```
ig10a25-site/
├── src/
│   ├── sections/       # Seções do site
│   │   ├── Navigation.tsx
│   │   ├── Hero.tsx
│   │   ├── About.tsx
│   │   ├── Schedule.tsx
│   │   ├── Subjects.tsx
│   │   ├── Gallery.tsx
│   │   ├── Contact.tsx
│   │   └── Footer.tsx
│   ├── components/     # Componentes reutilizáveis
│   ├── hooks/          # Custom hooks
│   ├── lib/            # Utilitários
│   ├── App.tsx         # Componente principal
│   ├── main.tsx        # Entry point
│   └── index.css       # Estilos globais
├── index.html
├── package.json
├── tsconfig.json
├── tailwind.config.js
└── vite.config.ts
```

## 🎨 Cores do Tema

| Cor | Hex | Uso |
|-----|-----|-----|
| Azul | `#3b82f6` | Primária |
| Roxo | `#a855f7` | Secundária |
| Laranja | `#f97316` | Destaque |
| Fundo | `#0a0e1a` | Background |

## 👥 Turma IG10A25

- **Curso:** Informática de Gestão
- **Ano:** 2024/2025
- **Alunos:** 24
- **Disciplinas:** 12

## 📄 Licença

Este projeto é de uso educacional para a turma IG10A25.

---

<p align="center">
  Feito com 💙 pela turma <strong>IG10A25</strong>
</p>
