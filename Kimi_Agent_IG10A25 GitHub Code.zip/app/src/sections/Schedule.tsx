import { useState } from 'react';
import { Clock, MapPin, User } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const weekDays = [
  { id: 'segunda', label: 'Segunda' },
  { id: 'terca', label: 'Terça' },
  { id: 'quarta', label: 'Quarta' },
  { id: 'quinta', label: 'Quinta' },
  { id: 'sexta', label: 'Sexta' },
];

const scheduleData: Record<string, Array<{
  time: string;
  subject: string;
  teacher: string;
  room: string;
  type: 'theory' | 'practice';
}>> = {
  segunda: [
    { time: '08:00 - 09:30', subject: 'Programação Web', teacher: 'Prof. Silva', room: 'Lab 3', type: 'practice' },
    { time: '09:45 - 11:15', subject: 'Bases de Dados', teacher: 'Prof. Santos', room: 'Sala 12', type: 'theory' },
    { time: '11:30 - 13:00', subject: 'Sistemas Operativos', teacher: 'Prof. Costa', room: 'Lab 2', type: 'practice' },
  ],
  terca: [
    { time: '08:00 - 09:30', subject: 'Análise de Sistemas', teacher: 'Prof. Ferreira', room: 'Sala 10', type: 'theory' },
    { time: '09:45 - 11:15', subject: 'Programação Orientada a Objetos', teacher: 'Prof. Silva', room: 'Lab 3', type: 'practice' },
    { time: '11:30 - 13:00', subject: 'Redes de Computadores', teacher: 'Prof. Oliveira', room: 'Lab 1', type: 'practice' },
  ],
  quarta: [
    { time: '08:00 - 09:30', subject: 'Bases de Dados', teacher: 'Prof. Santos', room: 'Lab 4', type: 'practice' },
    { time: '09:45 - 11:15', subject: 'Programação Web', teacher: 'Prof. Silva', room: 'Sala 12', type: 'theory' },
    { time: '11:30 - 13:00', subject: 'Inglês Técnico', teacher: 'Prof. Martins', room: 'Sala 8', type: 'theory' },
  ],
  quinta: [
    { time: '08:00 - 09:30', subject: 'Programação Orientada a Objetos', teacher: 'Prof. Silva', room: 'Lab 3', type: 'practice' },
    { time: '09:45 - 11:15', subject: 'Análise de Sistemas', teacher: 'Prof. Ferreira', room: 'Sala 10', type: 'theory' },
    { time: '11:30 - 13:00', subject: 'Redes de Computadores', teacher: 'Prof. Oliveira', room: 'Sala 15', type: 'theory' },
  ],
  sexta: [
    { time: '08:00 - 09:30', subject: 'Sistemas Operativos', teacher: 'Prof. Costa', room: 'Lab 2', type: 'practice' },
    { time: '09:45 - 11:15', subject: 'Projeto de Desenvolvimento', teacher: 'Prof. Silva', room: 'Lab 3', type: 'practice' },
    { time: '11:30 - 13:00', subject: 'Empreendedorismo', teacher: 'Prof. Rodrigues', room: 'Sala 5', type: 'theory' },
  ],
};

export function Schedule() {
  const [activeDay, setActiveDay] = useState('segunda');

  return (
    <section id="schedule" className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-blue-500/5 to-transparent" />
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <span className="inline-block px-4 py-1 rounded-full text-sm font-medium bg-purple-500/10 text-purple-400 mb-4">
            Horário
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-6">
            Horário das <span className="text-gradient">Aulas</span>
          </h2>
          <p className="max-w-2xl mx-auto text-muted-foreground text-lg">
            Consulta o horário semanal da turma IG10A25.
          </p>
        </div>

        {/* Schedule Tabs */}
        <Tabs value={activeDay} onValueChange={setActiveDay} className="w-full">
          <TabsList className="grid grid-cols-5 w-full max-w-2xl mx-auto mb-8 bg-white/5 p-1 rounded-xl">
            {weekDays.map((day) => (
              <TabsTrigger
                key={day.id}
                value={day.id}
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-purple-600 data-[state=active]:text-white rounded-lg text-sm font-medium transition-all"
              >
                {day.label}
              </TabsTrigger>
            ))}
          </TabsList>

          {weekDays.map((day) => (
            <TabsContent key={day.id} value={day.id} className="space-y-4">
              <div className="grid gap-4">
                {scheduleData[day.id].map((classItem, index) => (
                  <div
                    key={index}
                    className="glass rounded-xl p-6 hover:bg-white/10 transition-all duration-300 group"
                  >
                    <div className="flex flex-col md:flex-row md:items-center gap-4 md:gap-6">
                      {/* Time */}
                      <div className="flex items-center gap-3 min-w-[140px]">
                        <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                          <Clock className="w-5 h-5 text-blue-400" />
                        </div>
                        <span className="font-semibold text-foreground">{classItem.time}</span>
                      </div>

                      {/* Subject */}
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold mb-1">{classItem.subject}</h3>
                        <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <User className="w-4 h-4" />
                            {classItem.teacher}
                          </span>
                          <span className="flex items-center gap-1">
                            <MapPin className="w-4 h-4" />
                            {classItem.room}
                          </span>
                        </div>
                      </div>

                      {/* Type Badge */}
                      <div className="flex items-center gap-2">
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-medium ${
                            classItem.type === 'practice'
                              ? 'bg-orange-500/20 text-orange-400'
                              : 'bg-blue-500/20 text-blue-400'
                          }`}
                        >
                          {classItem.type === 'practice' ? 'Prática' : 'Teórica'}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>

        {/* Legend */}
        <div className="flex flex-wrap items-center justify-center gap-6 mt-8">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-blue-500/50" />
            <span className="text-sm text-muted-foreground">Aula Teórica</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-orange-500/50" />
            <span className="text-sm text-muted-foreground">Aula Prática</span>
          </div>
        </div>
      </div>
    </section>
  );
}
