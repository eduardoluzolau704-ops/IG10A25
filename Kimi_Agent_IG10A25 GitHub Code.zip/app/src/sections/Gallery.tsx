import { useState } from 'react';
import { ZoomIn, Camera, Users, Code, Calendar } from 'lucide-react';
import { Dialog, DialogContent } from '@/components/ui/dialog';

const galleryItems = [
  {
    id: 1,
    title: 'Aula de Programação',
    description: 'Trabalho em grupo no laboratório de informática',
    category: 'Aulas',
    icon: Code,
    color: 'bg-blue-500/20',
    iconColor: 'text-blue-400',
  },
  {
    id: 2,
    title: 'Projeto de Equipa',
    description: 'Desenvolvimento de aplicação web',
    category: 'Projetos',
    icon: Users,
    color: 'bg-purple-500/20',
    iconColor: 'text-purple-400',
  },
  {
    id: 3,
    title: 'Workshop de React',
    description: 'Sessão prática de frontend',
    category: 'Workshops',
    icon: Calendar,
    color: 'bg-orange-500/20',
    iconColor: 'text-orange-400',
  },
  {
    id: 4,
    title: 'Hackathon Interno',
    description: 'Competição de programação da turma',
    category: 'Eventos',
    icon: Code,
    color: 'bg-green-500/20',
    iconColor: 'text-green-400',
  },
  {
    id: 5,
    title: 'Apresentação de Projetos',
    description: 'Demonstração dos trabalhos finais',
    category: 'Projetos',
    icon: Users,
    color: 'bg-pink-500/20',
    iconColor: 'text-pink-400',
  },
  {
    id: 6,
    title: 'Visita Técnica',
    description: 'Visita a empresa de tecnologia',
    category: 'Eventos',
    icon: Camera,
    color: 'bg-cyan-500/20',
    iconColor: 'text-cyan-400',
  },
];

const categories = ['Todas', 'Aulas', 'Projetos', 'Workshops', 'Eventos'];

export function Gallery() {
  const [selectedCategory, setSelectedCategory] = useState('Todas');
  const [selectedItem, setSelectedItem] = useState<typeof galleryItems[0] | null>(null);

  const filteredItems = selectedCategory === 'Todas'
    ? galleryItems
    : galleryItems.filter(item => item.category === selectedCategory);

  return (
    <section id="gallery" className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-purple-500/5 to-transparent" />
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <span className="inline-block px-4 py-1 rounded-full text-sm font-medium bg-cyan-500/10 text-cyan-400 mb-4">
            Galeria
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-6">
            Momentos <span className="text-gradient">Especiais</span>
          </h2>
          <p className="max-w-2xl mx-auto text-muted-foreground text-lg">
            Registos dos nossos melhores momentos ao longo do curso.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                selectedCategory === category
                  ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white'
                  : 'bg-white/5 text-muted-foreground hover:bg-white/10 hover:text-foreground'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item, index) => (
            <div
              key={item.id}
              className="group cursor-pointer"
              onClick={() => setSelectedItem(item)}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="glass rounded-2xl overflow-hidden hover:bg-white/10 transition-all duration-300 hover:-translate-y-1 hover:shadow-glow">
                {/* Image Placeholder */}
                <div className={`aspect-[4/3] ${item.color} flex items-center justify-center relative overflow-hidden`}>
                  <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent" />
                  <item.icon className={`w-16 h-16 ${item.iconColor} opacity-50 group-hover:scale-110 transition-transform duration-300`} />
                  
                  {/* Overlay on hover */}
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <ZoomIn className="w-8 h-8 text-white" />
                  </div>
                </div>

                {/* Content */}
                <div className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs font-medium px-2 py-1 rounded-full bg-white/10 text-muted-foreground">
                      {item.category}
                    </span>
                  </div>
                  <h3 className="font-semibold mb-1 group-hover:text-blue-400 transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {item.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {filteredItems.length === 0 && (
          <div className="text-center py-16">
            <Camera className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-50" />
            <p className="text-muted-foreground">Nenhuma imagem encontrada nesta categoria.</p>
          </div>
        )}

        {/* Info Note */}
        <div className="mt-12 text-center">
          <p className="text-sm text-muted-foreground">
            Clique em qualquer item para ver mais detalhes.
          </p>
        </div>
      </div>

      {/* Detail Dialog */}
      <Dialog open={!!selectedItem} onOpenChange={() => setSelectedItem(null)}>
        <DialogContent className="max-w-2xl bg-background/95 backdrop-blur-xl border-white/10">
          {selectedItem && (
            <div className="space-y-4">
              <div className={`aspect-video ${selectedItem.color} rounded-xl flex items-center justify-center`}>
                <selectedItem.icon className={`w-24 h-24 ${selectedItem.iconColor} opacity-50`} />
              </div>
              <div>
                <span className="text-xs font-medium px-2 py-1 rounded-full bg-white/10 text-muted-foreground">
                  {selectedItem.category}
                </span>
                <h3 className="text-2xl font-bold mt-3">{selectedItem.title}</h3>
                <p className="text-muted-foreground mt-2">{selectedItem.description}</p>
              </div>
              <div className="flex items-center gap-4 pt-4 border-t border-white/10">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Calendar className="w-4 h-4" />
                  <span>2024/2025</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Users className="w-4 h-4" />
                  <span>Turma IG10A25</span>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
