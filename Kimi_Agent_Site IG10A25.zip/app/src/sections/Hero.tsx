import { useEffect, useRef } from 'react';
import { ArrowDown, Code, Database, Globe, Laptop } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function Hero() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Particles
    const particles: Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
      size: number;
      opacity: number;
    }> = [];

    for (let i = 0; i < 80; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        size: Math.random() * 2 + 1,
        opacity: Math.random() * 0.5 + 0.2,
      });
    }

    let animationId: number;

    const animate = () => {
      ctx.fillStyle = 'rgba(10, 14, 26, 0.1)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      particles.forEach((particle, i) => {
        particle.x += particle.vx;
        particle.y += particle.vy;

        if (particle.x < 0 || particle.x > canvas.width) particle.vx *= -1;
        if (particle.y < 0 || particle.y > canvas.height) particle.vy *= -1;

        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(59, 130, 246, ${particle.opacity})`;
        ctx.fill();

        // Connect particles
        particles.slice(i + 1).forEach((other) => {
          const dx = particle.x - other.x;
          const dy = particle.y - other.y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          if (distance < 150) {
            ctx.beginPath();
            ctx.moveTo(particle.x, particle.y);
            ctx.lineTo(other.x, other.y);
            ctx.strokeStyle = `rgba(59, 130, 246, ${0.1 * (1 - distance / 150)})`;
            ctx.stroke();
          }
        });
      });

      animationId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animationId);
    };
  }, []);

  const scrollToAbout = () => {
    const element = document.querySelector('#about');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Canvas Background */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ background: 'linear-gradient(135deg, #0a0e1a 0%, #1a1f3a 50%, #0f1429 100%)' }}
      />

      {/* Gradient Orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/20 rounded-full blur-[120px] animate-pulse-slow" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-[120px] animate-pulse-slow" style={{ animationDelay: '2s' }} />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-orange-500/10 rounded-full blur-[120px] animate-pulse-slow" style={{ animationDelay: '4s' }} />

      {/* Grid Pattern */}
      <div className="absolute inset-0 bg-grid opacity-50" />

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-8 animate-fade-in">
          <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
          <span className="text-sm text-muted-foreground">Turma 2024/2025</span>
        </div>

        {/* Main Title */}
        <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-black mb-6 animate-slide-down">
          <span className="text-gradient">IG10A25</span>
        </h1>

        {/* Subtitle */}
        <p className="text-xl sm:text-2xl md:text-3xl text-muted-foreground mb-4 animate-slide-up" style={{ animationDelay: '0.2s' }}>
          Informática de Gestão
        </p>

        {/* Description */}
        <p className="max-w-2xl mx-auto text-base sm:text-lg text-muted-foreground/80 mb-12 animate-slide-up" style={{ animationDelay: '0.4s' }}>
          Formando os profissionais do futuro em desenvolvimento de software,
          gestão de bases de dados e sistemas de informação empresarial.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16 animate-slide-up" style={{ animationDelay: '0.6s' }}>
          <Button
            size="lg"
            onClick={scrollToAbout}
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-8 py-6 text-lg rounded-xl shadow-glow hover:shadow-glow-purple transition-all"
          >
            Conhecer a Turma
          </Button>
          <Button
            size="lg"
            variant="outline"
            onClick={() => {
              const element = document.querySelector('#contact');
              if (element) element.scrollIntoView({ behavior: 'smooth' });
            }}
            className="border-white/20 hover:bg-white/5 px-8 py-6 text-lg rounded-xl"
          >
            Entrar em Contato
          </Button>
        </div>

        {/* Tech Icons */}
        <div className="flex items-center justify-center gap-8 animate-fade-in" style={{ animationDelay: '0.8s' }}>
          <div className="flex flex-col items-center gap-2 group">
            <div className="w-12 h-12 rounded-xl glass flex items-center justify-center group-hover:bg-blue-500/20 transition-colors">
              <Code className="w-6 h-6 text-blue-400" />
            </div>
            <span className="text-xs text-muted-foreground">Programação</span>
          </div>
          <div className="flex flex-col items-center gap-2 group">
            <div className="w-12 h-12 rounded-xl glass flex items-center justify-center group-hover:bg-purple-500/20 transition-colors">
              <Database className="w-6 h-6 text-purple-400" />
            </div>
            <span className="text-xs text-muted-foreground">Bases de Dados</span>
          </div>
          <div className="flex flex-col items-center gap-2 group">
            <div className="w-12 h-12 rounded-xl glass flex items-center justify-center group-hover:bg-orange-500/20 transition-colors">
              <Globe className="w-6 h-6 text-orange-400" />
            </div>
            <span className="text-xs text-muted-foreground">Web</span>
          </div>
          <div className="flex flex-col items-center gap-2 group">
            <div className="w-12 h-12 rounded-xl glass flex items-center justify-center group-hover:bg-cyan-500/20 transition-colors">
              <Laptop className="w-6 h-6 text-cyan-400" />
            </div>
            <span className="text-xs text-muted-foreground">Sistemas</span>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <ArrowDown className="w-6 h-6 text-muted-foreground" />
      </div>
    </section>
  );
}
