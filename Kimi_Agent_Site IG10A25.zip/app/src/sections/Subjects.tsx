import { useState } from 'react';
import { 
  Code, Database, Globe, Server, 
  Layers, Network, Settings, FileCode,
  ChevronDown, ChevronUp, BookOpen
} from 'lucide-react';

const subjects = [
  {
    id: 1,
    name: 'Programação Web',
    description: 'Desenvolvimento de aplicações web modernas utilizando HTML, CSS, JavaScript e frameworks atuais.',
    icon: Globe,
    color: 'from-blue-500 to-cyan-500',
    topics: ['HTML5 & CSS3', 'JavaScript ES6+', 'React', 'Node.js', 'Responsive Design'],
    hours: 120,
  },
  {
    id: 2,
    name: 'Bases de Dados',
    description: 'Conceção, implementação e gestão de sistemas de bases de dados relacionais e não relacionais.',
    icon: Database,
    color: 'from-purple-500 to-pink-500',
    topics: ['SQL', 'MySQL', 'MongoDB', 'Modelagem de Dados', 'Normalização'],
    hours: 100,
  },
  {
    id: 3,
    name: 'Programação Orientada a Objetos',
    description: 'Paradigma de programação baseado em objetos, classes, herança, polimorfismo e encapsulamento.',
    icon: Code,
    color: 'from-orange-500 to-amber-500',
    topics: ['Classes e Objetos', 'Herança', 'Polimorfismo', 'Encapsulamento', 'Java'],
    hours: 110,
  },
  {
    id: 4,
    name: 'Análise de Sistemas',
    description: 'Metodologias e técnicas para análise, projeto e desenvolvimento de sistemas de informação.',
    icon: Layers,
    color: 'from-green-500 to-emerald-500',
    topics: ['UML', 'Diagramas', 'Requisitos', 'Casos de Uso', 'Modelagem'],
    hours: 90,
  },
  {
    id: 5,
    name: 'Redes de Computadores',
    description: 'Fundamentos de redes, protocolos, arquiteturas e segurança de redes informáticas.',
    icon: Network,
    color: 'from-red-500 to-rose-500',
    topics: ['TCP/IP', 'OSI', 'Roteamento', 'Switching', 'Segurança'],
    hours: 80,
  },
  {
    id: 6,
    name: 'Sistemas Operativos',
    description: 'Instalação, configuração e administração de sistemas operativos Windows e Linux.',
    icon: Settings,
    color: 'from-indigo-500 to-violet-500',
    topics: ['Windows Server', 'Linux', 'Shell Script', 'Virtualização', 'Docker'],
    hours: 85,
  },
];

export function Subjects() {
  const [expandedSubject, setExpandedSubject] = useState<number | null>(null);

  const toggleSubject = (id: number) => {
    setExpandedSubject(expandedSubject === id ? null : id);
  };

  return (
    <section id="subjects" className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-dots opacity-20" />
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-1 rounded-full text-sm font-medium bg-orange-500/10 text-orange-400 mb-4">
            Disciplinas
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-6">
            O Que <span className="text-gradient">Aprendemos</span>
          </h2>
          <p className="max-w-2xl mx-auto text-muted-foreground text-lg">
            Conhece as disciplinas que compõem o nosso currículo e as competências que desenvolvemos.
          </p>
        </div>

        {/* Subjects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {subjects.map((subject, index) => (
            <div
              key={subject.id}
              className="group relative"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="glass rounded-2xl overflow-hidden hover:bg-white/10 transition-all duration-300 hover:-translate-y-1">
                {/* Header */}
                <div className="p-6">
                  <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${subject.color} flex items-center justify-center mb-4 group-hover:shadow-glow transition-shadow`}>
                    <subject.icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{subject.name}</h3>
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {subject.description}
                  </p>
                </div>

                {/* Expandable Content */}
                <div
                  className={`overflow-hidden transition-all duration-300 ${
                    expandedSubject === subject.id ? 'max-h-64' : 'max-h-0'
                  }`}
                >
                  <div className="px-6 pb-4">
                    <div className="border-t border-white/10 pt-4">
                      <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
                        <BookOpen className="w-4 h-4 text-muted-foreground" />
                        Tópicos Abordados
                      </h4>
                      <ul className="space-y-1">
                        {subject.topics.map((topic, i) => (
                          <li key={i} className="text-sm text-muted-foreground flex items-center gap-2">
                            <span className="w-1 h-1 rounded-full bg-blue-400" />
                            {topic}
                          </li>
                        ))}
                      </ul>
                      <div className="mt-4 flex items-center gap-2 text-sm">
                        <span className="text-muted-foreground">Carga Horária:</span>
                        <span className="font-semibold">{subject.hours}h</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Toggle Button */}
                <button
                  onClick={() => toggleSubject(subject.id)}
                  className="w-full py-3 border-t border-white/10 flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-foreground hover:bg-white/5 transition-colors"
                >
                  {expandedSubject === subject.id ? (
                    <>
                      <ChevronUp className="w-4 h-4" />
                      Ver menos
                    </>
                  ) : (
                    <>
                      <ChevronDown className="w-4 h-4" />
                      Ver mais
                    </>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Additional Info */}
        <div className="mt-16 glass rounded-2xl p-8 text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Server className="w-8 h-8 text-blue-400" />
            <FileCode className="w-8 h-8 text-purple-400" />
          </div>
          <h3 className="text-xl font-semibold mb-2">Formação Completa</h3>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Além das disciplinas técnicas, o curso inclui formação em áreas como 
            inglês técnico, empreendedorismo e comunicação, preparando os alunos 
            para o mercado de trabalho.
          </p>
        </div>
      </div>
    </section>
  );
}
