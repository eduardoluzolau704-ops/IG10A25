import { useEffect, useRef, useState } from 'react';
import { Users, BookOpen, Award, Calendar, Target, Lightbulb } from 'lucide-react';

const stats = [
  { icon: Users, value: 24, label: 'Alunos', suffix: '' },
  { icon: BookOpen, value: 12, label: 'Disciplinas', suffix: '' },
  { icon: Calendar, value: 3, label: 'Anos de Curso', suffix: 'º' },
  { icon: Award, value: 100, label: 'Dedicados', suffix: '%' },
];

const features = [
  {
    icon: Target,
    title: 'Objetivo',
    description: 'Formar profissionais competentes em desenvolvimento e gestão de sistemas informáticos empresariais.',
  },
  {
    icon: Lightbulb,
    title: 'Inovação',
    description: 'Aplicação de tecnologias modernas e metodologias ágeis em projetos reais.',
  },
  {
    icon: Users,
    title: 'Trabalho em Equipa',
    description: 'Desenvolvimento de competências de colaboração e comunicação em projetos de grupo.',
  },
];

function AnimatedCounter({ value, suffix }: { value: number; suffix: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !hasAnimated.current) {
          hasAnimated.current = true;
          let start = 0;
          const end = value;
          const duration = 2000;
          const increment = end / (duration / 16);

          const timer = setInterval(() => {
            start += increment;
            if (start >= end) {
              setCount(end);
              clearInterval(timer);
            } else {
              setCount(Math.floor(start));
            }
          }, 16);
        }
      },
      { threshold: 0.5 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [value]);

  return (
    <span ref={ref}>
      {count}
      {suffix}
    </span>
  );
}

export function About() {
  return (
    <section id="about" className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-dots opacity-30" />
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-1 rounded-full text-sm font-medium bg-blue-500/10 text-blue-400 mb-4">
            Sobre Nós
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-6">
            Conhece a <span className="text-gradient">IG10A25</span>
          </h2>
          <p className="max-w-2xl mx-auto text-muted-foreground text-lg">
            Uma turma unida pelo objetivo comum de se tornarem profissionais de excelência
            na área da Informática de Gestão.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mb-16">
          {stats.map((stat, index) => (
            <div
              key={stat.label}
              className="relative group"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="glass rounded-2xl p-6 text-center hover:bg-white/10 transition-all duration-300 hover:-translate-y-1">
                <div className="w-12 h-12 mx-auto mb-4 rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 flex items-center justify-center">
                  <stat.icon className="w-6 h-6 text-blue-400" />
                </div>
                <div className="text-3xl md:text-4xl font-bold text-gradient mb-1">
                  <AnimatedCounter value={stat.value} suffix={stat.suffix} />
                </div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className="glass rounded-2xl p-8 hover:bg-white/10 transition-all duration-300 group"
              style={{ animationDelay: `${index * 0.15}s` }}
            >
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center mb-6 group-hover:shadow-glow transition-shadow">
                <feature.icon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
              <p className="text-muted-foreground leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Quote */}
        <div className="mt-16 text-center">
          <blockquote className="relative">
            <div className="text-6xl text-blue-500/20 absolute -top-8 left-1/2 -translate-x-1/2">"</div>
            <p className="text-xl md:text-2xl italic text-muted-foreground max-w-3xl mx-auto pt-8">
              A tecnologia move o mundo, mas são as pessoas que movem a tecnologia.
              Juntos, somos mais fortes.
            </p>
            <footer className="mt-4 text-sm text-muted-foreground">
              — Turma IG10A25
            </footer>
          </blockquote>
        </div>
      </div>
    </section>
  );
}
